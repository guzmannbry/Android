package com.example.gridviewintent;

import android.net.Uri;

public class Contact {

	private Uri imageUri;
	private String name ;
	public Contact(Uri imageUri, String name) {
		super();
		this.imageUri = imageUri;
		this.name = name;
	}
	public Uri getImage() {
		return imageUri;
	}
	public void setImage(Uri imageUri) {
		this.imageUri = imageUri;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
}
