/** Automatically generated file. DO NOT MODIFY */
package com.example.loveexam;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}