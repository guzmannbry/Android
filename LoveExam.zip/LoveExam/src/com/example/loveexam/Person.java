package com.example.loveexam;

public class Person {
	private int image;
	private String txtname,txtnumber;
	public Person(int image, String txtname, String txtnumber) {
		super();
		this.image = image;
		this.txtname = txtname;
		this.txtnumber = txtnumber;
	}
	public int getImage() {
		return image;
	}
	public void setImage(int image) {
		this.image = image;
	}
	public String getTxtname() {
		return txtname;
	}
	public void setTxtname(String txtname) {
		this.txtname = txtname;
	}
	public String getTxtnumber() {
		return txtnumber;
	}
	public void setTxtnumber(String txtnumber) {
		this.txtnumber = txtnumber;
	}
	
	
}
