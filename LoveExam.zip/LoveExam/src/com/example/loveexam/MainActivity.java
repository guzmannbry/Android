package com.example.loveexam;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

public class MainActivity extends Activity implements OnClickListener, OnItemClickListener {

	ListView lv;
	ArrayList<Person> list = new ArrayList<Person>();
	MyAdapter adapter;
	EditText txtname , txtnumber;
	AlertDialog dialog;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        lv=(ListView)this.findViewById(R.id.listView1);
        adapter= new MyAdapter(this,list);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(this);
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		txtname = new EditText(this);
		txtname.setPadding(10,10,10,10);
		txtname.setHint("Enter name");
		
		txtnumber = new EditText(this);
		txtnumber.setPadding(10,10,10,10);
		txtnumber.setInputType(InputType.TYPE_CLASS_NUMBER);
		txtnumber.setHint("Enter contact");
		
		LinearLayout lay = new LinearLayout(this);
		lay.setOrientation(LinearLayout.VERTICAL);
		lay.addView(txtname);
		lay.addView(txtnumber);
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Add Item");
			builder.setView(lay);
			builder.setPositiveButton("Save",this);
			builder.setNegativeButton("Cancel",this);
		
		
		 dialog = builder.create();
		 dialog.show();
		
		
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
		
		switch(arg1){
		case DialogInterface.BUTTON_POSITIVE:
			String name = this.txtname.getText().toString();
			String num = this.txtnumber.getText().toString();
			if(!name.equals("")&&!num.equals("")){
				list.add(new Person(R.drawable.ic_launcher,name,num));
				adapter.notifyDataSetChanged();	
			}
			break;
		case DialogInterface.BUTTON_NEGATIVE:
			dialog.dismiss();
		
		}
		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
	
	}
    
    
    
    
}
