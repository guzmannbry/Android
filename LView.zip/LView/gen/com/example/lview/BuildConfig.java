/** Automatically generated file. DO NOT MODIFY */
package com.example.lview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}