package com.example.mylatlng_prefinal;


import android.app.Activity;
import android.os.Bundle;


public class About extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
	}

}
