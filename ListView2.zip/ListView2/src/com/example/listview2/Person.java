package com.example.listview2;

public class Person{
	private int image;
	private String txtName,number;

	public Person(int image, String txtName, String number) {
		super();
		this.image = image;
		this.txtName = txtName;
		this.number = number;
	}
	
	public int getImage() {
		return image;
	}
	public void setImage(int image) {
		this.image = image;
	}
	public String getTxtName() {
		return txtName;
	}
	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	

}
