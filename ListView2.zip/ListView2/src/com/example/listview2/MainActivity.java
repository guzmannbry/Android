package com.example.listview2;

import java.util.ArrayList;

import com.example.listview.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener, OnItemClickListener {

	ListView lv;
	ArrayList <Person> list;
	//ArrayAdapter<String> adapter;
	AlertDialog.Builder builder;
	AlertDialog dialog;
	EditText txtName,number;
	MyAdapter adapter;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.lv=(ListView)this.findViewById(R.id.listView1);
        //adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
        
       // list.add(new Person(R.drawable.ic_launcher,"",""));
        adapter=new MyAdapter(this,list);
        this.lv.setAdapter(adapter);
        this.lv.setOnItemClickListener(this);
        
        
    }


    @Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
    		txtName = new EditText(this);
    		txtName.setPadding(10, 10, 10, 10);
    		txtName.setHint("Enter Name");
    	
    		number = new EditText(this);
    		number.setPadding(10,10,10,10);
    		number.setInputType(InputType.TYPE_CLASS_NUMBER);
    		number.setHint("Enter Contact");
    		
    		LinearLayout layout=new LinearLayout(this);
    		layout.setOrientation(LinearLayout.VERTICAL);
    		layout.addView(txtName);
    		layout.addView(number);
    		
    		builder = new AlertDialog.Builder(this);
    		builder.setTitle("Add Item");
    		builder.setView(layout);
    		builder.setPositiveButton("Save",this);
    		builder.setNegativeButton("Cancel",this);
    		
    		
    	    dialog = builder.create();
    		dialog.show();
    	
    	return super.onOptionsItemSelected(item);
	}

    @Override
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
    	
    	
		switch(arg1){
		case DialogInterface.BUTTON_POSITIVE:
			
			String name = this.txtName.getText().toString();
			//list.add(s);
			String num = this.number.getText().toString();
			//list.add(b);
			
			if(!name.equals("")&&!num.equals("")){
				//this.list.add(new Person(R.drawable.ic_launcher,name,num));
			//	list.add(name);
				//list.add(num);
				
				list.add(new Person(R.drawable.ic_launcher,name,num));
				adapter.notifyDataSetChanged();
				
			}else{
				Toast.makeText(this,"",Toast.LENGTH_SHORT);
			}
			break;
		case DialogInterface.BUTTON_NEGATIVE:
			dialog.dismiss();
		}
	}
    
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		String items = this.txtName.getText().toString();
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Selected Item");
			builder.setMessage(list.set(arg2,items));
	
	}


	/*@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
	
		String  items = this.txtName.getText().toString();	
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Selected Item");
			builder.setMessage(list.set(arg2, items));
			builder.setNeutralButton("Ok",null );
			adapter.areAllItemsEnabled();
		AlertDialog dialog = builder.create();
			dialog.show();
	}*/


}
