package com.example.intentg;

import java.util.ArrayList;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{

    
	ListView lv;
	ArrayList<Contact> list = new ArrayList<Contact>();
	ItemAdapter adapter;
	AdapterView.AdapterContextMenuInfo info;
	AlertDialog dialog;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        this.lv=(ListView)this.findViewById(R.id.listView1);
        this.adapter=new ItemAdapter(this,list);
        this.lv.setAdapter(adapter);
        this.registerForContextMenu(lv);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.contextmenu, menu);
        info=(AdapterContextMenuInfo) menuInfo;
        menu.setHeaderTitle(list.get(info.position).getName());
        

	}



	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		int select=item.getItemId();
		switch(select){
		case R.id.delete:
			/*list.remove(info.position);
			Toast.makeText(this,"Deleted",Toast.LENGTH_SHORT).show();	
			this.adapter.notifyDataSetChanged();*/
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setIcon(R.drawable.ic_launcher);
			b.setTitle("Delete Contact");
			b.setMessage(String.format("Are you sure you want to delete %s ? ",list.get(info.position).getName()));
			b.setPositiveButton("Yes",this);
			b.setNegativeButton("No",this);
			AlertDialog dialog = b.create();
			dialog.show();
			break;
		case R.id.view:
			ImageView image = new ImageView(this);
		//	img.setImageURI(list.get(info.position).getImageUri());
			image.setImageURI(list.get(info.position).getImageUri());
			//image.set
			TextView name = new TextView(this);
			name.setPadding(10, 10, 10, 10);
			name.setText(list.get(info.position).getName());
			
			TextView tel = new TextView(this);
			tel.setPadding(10, 10, 10, 10);
			tel.setText(list.get(info.position).getTel());
		
			
			
			LinearLayout layout = new LinearLayout (this);
			layout.setOrientation(LinearLayout.HORIZONTAL);
			//layout.setGravity(Gravity.CENTER_HORIZONTAL);
			
			layout.addView(image);
			layout.addView(name);
			layout.addView(tel);
			
			
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			LayoutInflater n = getLayoutInflater(); 
			builder.setTitle(String.format("Details of %s ",list.get(info.position).getName()));
			builder.setIcon(R.drawable.ic_launcher);
			builder.setView(layout);
			builder.setNeutralButton("OK",null);
			
			
			dialog = builder.create();
			dialog.show();
			//break;
			
		}
		
		
		
		return super.onContextItemSelected(item);
	}

	@Override
	public void onClick(DialogInterface arg0 , int arg1) {
			switch(arg1){
			case DialogInterface.BUTTON_POSITIVE:
				list.remove(info.position);
				Toast.makeText(this, "Deleted",Toast.LENGTH_SHORT).show();
				this.adapter.notifyDataSetChanged();
				break;
			case DialogInterface.BUTTON_NEGATIVE:
				dialog.dismiss();
			}
		
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent intent = new Intent(this,GuzmanActivity.class);
		this.startActivityForResult(intent,0);//add new contact
		return super.onOptionsItemSelected(item);
		}
	
	

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode==Activity.RESULT_OK){
			if(requestCode==0){
				Bundle b = data.getExtras();
				Uri image = b.getParcelable("image");
				String name =b.getString("name");
				String tel=b.getString("tel");
			
			Contact contact = new Contact(image,name,tel);
			list.add(contact);
			adapter.notifyDataSetChanged();
			}
			
		}
		
	}
	
	
   }
