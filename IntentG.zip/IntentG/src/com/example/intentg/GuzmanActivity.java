package com.example.intentg;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class GuzmanActivity extends Activity implements OnClickListener {

	ImageView iv;
	EditText txtName,txtTel;
	Button btnOK,btnCancel;
	Uri image;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.guzman_layout);
		
		this.iv=(ImageView)this.findViewById(R.id.imageView1);
		this.txtName=(EditText)this.findViewById(R.id.editText1);
		this.txtTel=(EditText)this.findViewById(R.id.editText2);
		this.btnOK=(Button)this.findViewById(R.id.button1);
		this.btnCancel=(Button)this.findViewById(R.id.button2);
		
		this.btnOK.setOnClickListener(this);
		this.btnCancel.setOnClickListener(this);
		this.iv.setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		int id = arg0.getId();
		switch(id){
		case R.id.imageView1:
			
			Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
			this.startActivityForResult(intent,111);
			break;
		case R.id.button1:
			String name = this.txtName.getText().toString();
			String telephone = this.txtTel.getText().toString();
			
			Intent blind = new Intent();
				blind.putExtra("image",image);
				blind.putExtra("name",name);
				blind.putExtra("tel",telephone);
			this.setResult(Activity.RESULT_OK,blind);
		
			
			Toast.makeText(this,"New Contact Added",Toast.LENGTH_SHORT).show();
			this.finish();
			break;
		case R.id.button2:
			Toast.makeText(this,"Cancel Adding",Toast.LENGTH_SHORT).show();
			this.finish();
		}
		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
	
		image = data.getData();
		this.iv.setImageURI(image);
		
		
		
	}

	
}
